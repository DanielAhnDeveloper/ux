(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimUtil, {
        "loadScrollBars": function() {
            jQuery(".s-03c3cbb6-2c16-4eab-9656-4a004b7c4cc1 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-c69ce58f-74d6-4777-b1b6-27543b11306e .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-499c62f2-3960-4755-8d73-38cf8e62c219 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-41bccfcf-737a-4dbe-b2c4-a1d427287daa .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-182427d0-8cad-4dcf-ad3f-86438fa7859e .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-fa6c11bf-b7ea-44cc-9682-3f7a02d50397 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-e7c0a95d-e4df-400f-ad00-2a31c0778cab .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-a94c7dcf-a726-4a34-8c64-291e0bcee780 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-2de42f79-7fcc-46ba-b36d-adc6c3691cc2 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-f7400489-ab77-4a2e-b86c-bea4082d1592 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-2bf6b16f-3d22-4da6-9c1c-9c0848843692 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-a72f0f98-6c3e-4fe4-8330-a46f64fe7152 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-71fd5d72-67e5-40e6-a3f1-944a5ec5deaa .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-71fd5d72-67e5-40e6-a3f1-944a5ec5deaa #s-Content .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-7592f3ac-ab45-4043-ae01-560b524a4883 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-828f7be9-f963-49c9-837a-ea5ffedd0577 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-9ba418cd-f800-4b86-9a2f-831d30e97916 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-9ba418cd-f800-4b86-9a2f-831d30e97916 #s-Favorites .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-9ba418cd-f800-4b86-9a2f-831d30e97916 #s-All .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-9ba418cd-f800-4b86-9a2f-831d30e97916 #s-Recent .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-9ba418cd-f800-4b86-9a2f-831d30e97916 #s-Favorites_1 .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-9ba418cd-f800-4b86-9a2f-831d30e97916 #s-All_1 .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-9ba418cd-f800-4b86-9a2f-831d30e97916 #s-Recent_1 .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-e6c54754-41fc-42e2-a551-fface62ea3d8 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-f67fa4a0-f5cf-4c56-86b6-1628ac729ca8 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-f67fa4a0-f5cf-4c56-86b6-1628ac729ca8 #s-Favorites .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-f67fa4a0-f5cf-4c56-86b6-1628ac729ca8 #s-All .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-f67fa4a0-f5cf-4c56-86b6-1628ac729ca8 #s-Recent .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);