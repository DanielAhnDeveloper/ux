(function(window, undefined) {

  var jimLinks = {
    "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1" : {
      "Two-line-item_24" : [
        "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1"
      ],
      "Two-line-item_28" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Two-line-item_12" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "Two-line-item_34" : [
        "9ba418cd-f800-4b86-9a2f-831d30e97916"
      ],
      "Label_46" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Triangle_3" : [
        "41bccfcf-737a-4dbe-b2c4-a1d427287daa"
      ],
      "Triangle_4" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "more-vertical_2" : [
        "7592f3ac-ab45-4043-ae01-560b524a4883"
      ]
    },
    "c69ce58f-74d6-4777-b1b6-27543b11306e" : {
      "Cell_14" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Label_45" : [
        "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1"
      ],
      "Button_1" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "raised_Button" : [
        "f7400489-ab77-4a2e-b86c-bea4082d1592"
      ],
      "Button_2" : [
        "2de42f79-7fcc-46ba-b36d-adc6c3691cc2"
      ],
      "Button_3" : [
        "e7c0a95d-e4df-400f-ad00-2a31c0778cab"
      ]
    },
    "499c62f2-3960-4755-8d73-38cf8e62c219" : {
      "Triangle" : [
        "71fd5d72-67e5-40e6-a3f1-944a5ec5deaa"
      ],
      "arrow-back_4" : [
        "71fd5d72-67e5-40e6-a3f1-944a5ec5deaa"
      ]
    },
    "41bccfcf-737a-4dbe-b2c4-a1d427287daa" : {
      "arrow-back_4" : [
        "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1"
      ]
    },
    "182427d0-8cad-4dcf-ad3f-86438fa7859e" : {
      "arrow-back_4" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ]
    },
    "fa6c11bf-b7ea-44cc-9682-3f7a02d50397" : {
      "Two-line-item_24" : [
        "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1"
      ],
      "Two-line-item_28" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Two-line-item_12" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "Two-line-item_34" : [
        "9ba418cd-f800-4b86-9a2f-831d30e97916"
      ],
      "Label_48" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Triangle_4" : [
        "41bccfcf-737a-4dbe-b2c4-a1d427287daa"
      ],
      "Triangle_5" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "more-vertical_3" : [
        "7592f3ac-ab45-4043-ae01-560b524a4883"
      ],
      "Cell_14" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Rectangle_499" : [
        "fa6c11bf-b7ea-44cc-9682-3f7a02d50397"
      ],
      "Rectangle_486" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Rectangle_501" : [
        "a72f0f98-6c3e-4fe4-8330-a46f64fe7152"
      ],
      "Ellipse_1" : [
        "c69ce58f-74d6-4777-b1b6-27543b11306e"
      ],
      "Label_45" : [
        "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1"
      ]
    },
    "e7c0a95d-e4df-400f-ad00-2a31c0778cab" : {
      "arrow-back_4" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ]
    },
    "a94c7dcf-a726-4a34-8c64-291e0bcee780" : {
      "arrow-back_4" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "Cell_4" : [
        "2de42f79-7fcc-46ba-b36d-adc6c3691cc2"
      ],
      "Image_7" : [
        "2de42f79-7fcc-46ba-b36d-adc6c3691cc2"
      ],
      "Text_4" : [
        "2de42f79-7fcc-46ba-b36d-adc6c3691cc2"
      ]
    },
    "2de42f79-7fcc-46ba-b36d-adc6c3691cc2" : {
      "Button_1" : [
        "828f7be9-f963-49c9-837a-ea5ffedd0577"
      ],
      "Button_2" : [
        "2de42f79-7fcc-46ba-b36d-adc6c3691cc2"
      ],
      "Button_3" : [
        "e7c0a95d-e4df-400f-ad00-2a31c0778cab"
      ],
      "arrow-back_4" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ]
    },
    "f7400489-ab77-4a2e-b86c-bea4082d1592" : {
      "Cell_14" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Label_45" : [
        "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1"
      ],
      "Button_1" : [
        "828f7be9-f963-49c9-837a-ea5ffedd0577"
      ],
      "Button_2" : [
        "2de42f79-7fcc-46ba-b36d-adc6c3691cc2"
      ],
      "Button_3" : [
        "e7c0a95d-e4df-400f-ad00-2a31c0778cab"
      ],
      "flat_Button_lightTheme_1" : [
        "c69ce58f-74d6-4777-b1b6-27543b11306e"
      ]
    },
    "2bf6b16f-3d22-4da6-9c1c-9c0848843692" : {
      "Two-line-item_24" : [
        "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1"
      ],
      "Two-line-item_28" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Two-line-item_12" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "Two-line-item_34" : [
        "9ba418cd-f800-4b86-9a2f-831d30e97916"
      ],
      "Label_48" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Triangle_4" : [
        "41bccfcf-737a-4dbe-b2c4-a1d427287daa"
      ],
      "Triangle_5" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "more-vertical_3" : [
        "7592f3ac-ab45-4043-ae01-560b524a4883"
      ],
      "Cell_14" : [
        "fa6c11bf-b7ea-44cc-9682-3f7a02d50397"
      ],
      "Rectangle_499" : [
        "fa6c11bf-b7ea-44cc-9682-3f7a02d50397"
      ],
      "Rectangle_486" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Rectangle_501" : [
        "a72f0f98-6c3e-4fe4-8330-a46f64fe7152"
      ],
      "Ellipse_1" : [
        "c69ce58f-74d6-4777-b1b6-27543b11306e"
      ],
      "Label_45" : [
        "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1"
      ]
    },
    "a72f0f98-6c3e-4fe4-8330-a46f64fe7152" : {
      "Two-line-item_24" : [
        "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1"
      ],
      "Two-line-item_28" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Two-line-item_12" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "Two-line-item_34" : [
        "9ba418cd-f800-4b86-9a2f-831d30e97916"
      ],
      "Cell_14" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Rectangle_499" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Rectangle_486" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Rectangle_501" : [
        "a72f0f98-6c3e-4fe4-8330-a46f64fe7152"
      ],
      "Ellipse_1" : [
        "c69ce58f-74d6-4777-b1b6-27543b11306e"
      ],
      "Label_45" : [
        "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1"
      ]
    },
    "71fd5d72-67e5-40e6-a3f1-944a5ec5deaa" : {
      "Image_63" : [
        "e6c54754-41fc-42e2-a551-fface62ea3d8"
      ],
      "Label_53" : [
        "e6c54754-41fc-42e2-a551-fface62ea3d8"
      ],
      "Image_125" : [
        "499c62f2-3960-4755-8d73-38cf8e62c219"
      ],
      "Label_55" : [
        "499c62f2-3960-4755-8d73-38cf8e62c219"
      ],
      "Triangle" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "attachment_5" : [
        "e6c54754-41fc-42e2-a551-fface62ea3d8"
      ],
      "arrow-back_4" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8",
        "9ba418cd-f800-4b86-9a2f-831d30e97916"
      ]
    },
    "7592f3ac-ab45-4043-ae01-560b524a4883" : {
      "Two-line-item_24" : [
        "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1"
      ],
      "Two-line-item_28" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Two-line-item_12" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "Two-line-item_34" : [
        "9ba418cd-f800-4b86-9a2f-831d30e97916"
      ],
      "Label_46" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Triangle_3" : [
        "41bccfcf-737a-4dbe-b2c4-a1d427287daa"
      ],
      "Triangle_4" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "more-vertical_2" : [
        "7592f3ac-ab45-4043-ae01-560b524a4883"
      ],
      "Rectangle_16" : [
        "2bf6b16f-3d22-4da6-9c1c-9c0848843692"
      ],
      "Rectangle_17" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "Rectangle_18" : [
        "41bccfcf-737a-4dbe-b2c4-a1d427287daa"
      ]
    },
    "828f7be9-f963-49c9-837a-ea5ffedd0577" : {
      "Button_2" : [
        "2de42f79-7fcc-46ba-b36d-adc6c3691cc2"
      ],
      "Button_3" : [
        "182427d0-8cad-4dcf-ad3f-86438fa7859e"
      ],
      "arrow-back_4" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ]
    },
    "9ba418cd-f800-4b86-9a2f-831d30e97916" : {
      "Rectangle_39" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_40" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Triangle_1" : [
        "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1"
      ],
      "icon_4" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "Text_11" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "icon_5" : [
        "9ba418cd-f800-4b86-9a2f-831d30e97916"
      ],
      "Text_10" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_20" : [
        "9ba418cd-f800-4b86-9a2f-831d30e97916"
      ]
    },
    "e6c54754-41fc-42e2-a551-fface62ea3d8" : {
      "Triangle" : [
        "71fd5d72-67e5-40e6-a3f1-944a5ec5deaa"
      ],
      "Content_panel" : [
        "71fd5d72-67e5-40e6-a3f1-944a5ec5deaa"
      ],
      "call" : [
        "71fd5d72-67e5-40e6-a3f1-944a5ec5deaa"
      ]
    },
    "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8" : {
      "Rectangle_3" : [
        "a94c7dcf-a726-4a34-8c64-291e0bcee780"
      ],
      "Triangle" : [
        "03c3cbb6-2c16-4eab-9656-4a004b7c4cc1"
      ],
      "icon_1" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "Text_9" : [
        "f67fa4a0-f5cf-4c56-86b6-1628ac729ca8"
      ],
      "icon_3" : [
        "9ba418cd-f800-4b86-9a2f-831d30e97916"
      ],
      "Text_10" : [
        "9ba418cd-f800-4b86-9a2f-831d30e97916"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "arrow-back_4" : [
        "9ba418cd-f800-4b86-9a2f-831d30e97916"
      ],
      "Image_3" : [
        "e6c54754-41fc-42e2-a551-fface62ea3d8"
      ],
      "Text_2" : [
        "e6c54754-41fc-42e2-a551-fface62ea3d8"
      ],
      "Image_76" : [
        "71fd5d72-67e5-40e6-a3f1-944a5ec5deaa"
      ],
      "Text_7" : [
        "71fd5d72-67e5-40e6-a3f1-944a5ec5deaa"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);